from django.apps import AppConfig


class RealtimeConfig(AppConfig):
    name = "apps.realtime"
    label = "realtime"
    verbose_name = "Realtime — WebSocket Gateway"
