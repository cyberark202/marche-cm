from django.apps import AppConfig


class ComplianceConfig(AppConfig):
    name = "apps.compliance"
    label = "compliance"
    verbose_name = "Compliance — KYC & AML"
